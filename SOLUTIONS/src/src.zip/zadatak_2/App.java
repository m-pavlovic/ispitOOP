package zadatak_2;

public class App {

    public static void main(String[] args) {
        MainFrame mainFrame = new MainFrame();
    }
}
